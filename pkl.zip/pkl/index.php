<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="it">
    <meta name="keywords" content="Rapoo,creative, agency, startup, Mobicon,onepage, clean, modern,business, company,it">
    <meta name="author" content="Dreambuzz">

    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/themify/themify-icons.css">

    <link rel="stylesheet" href="assets/css/slick.css">
    <link rel="stylesheet" href="assets/css/slick-theme.css">
    <link rel="stylesheet" href="assets/css/all.css">

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <script type="text/JavaScript" src="js/sha512.js"></script> 
        <script type="text/JavaScript" src="js/forms.js"></script>
    <title>Info Pelatihan Seminar</title>
</head>

<?php
include_once 'includes/db_connect.php';
include_once 'includes/register.inc.php';
include_once 'includes/functions.php';

if (login_check($mysqli) == true) {
    $logged = 'Anda masih login';
} else {
    $logged = '';
}
?>

<body class="top-header">

    <!-- LOADER TEMPLATE -->
    <div id="page-loader">
        <div class="loader-icon fa fa-spin colored-border"></div>
    </div>
    <!-- /LOADER TEMPLATE -->

    <div class="logo-bar d-none d-md-block d-lg-block bg-light">
        <div class="container">
            <div class="row">
                <div class="col-lg-2">
                    <div class="logo d-none d-lg-block">
                        <!-- Brand -->
                        <a class="navbar-brand js-scroll-trigger" href="index.php" style="text-align : center">
                            <h2>INFO PELATIHAN SEMINAR NASIONAL & SEMINAR INTERNASIONAL</h2>
                            <p><?php echo $logged ?>.</p>
                        </a>
                    </div>
                </div>
               </div>
            </div>
        </div>
    </div>

    <!-- NAVBAR
    ================================================= -->
    <div class="container col-md-9">
    <div class="main-navigation container-fluid" id="mainmenu-area">
            <nav class="navbar navbar-expand-lg navbar-dark bg-primary main-nav navbar-togglable">
                <!-- Toggler -->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="fa fa-bars"></span>
                </button>
                <div class="container col-md-12">
                <!-- Collapse -->
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <!-- Links -->
                    <ul class="navbar-nav container-fluid">
						<li class="nav-item">
							<a class="nav-link dropdown" href="proses_login.php" id="navbarWelcome" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Login
                            </a>
							<?php
                                if (isset($_GET['error'])) {
                                    echo "<script type='text/javascript'>alert('Pastikan Data Yang Anda Isi Sudah Benar');document.location='index.php'</script>";
                                }
                                ?>
                            <div class="dropdown-menu" aria-labelledby="navbarWelcome"> 
                                <form class="container" style="margin:3px; width: 100%" action="includes/process_login.php" method="post" name="login_form"> 			
                                <div class="form-group">
                                    Email: <input type="text" class="form-control" style="width:100%" name='email' id='email'  placeholder="Email">
								</div>     
                                <div class="form-group">
                                    Password: <input type="password" class="form-control" style="width:100%" name="password" id="password"  placeholder="Password">
								</div>
                                    <input type="submit" class="btn btn-primary" value="Login" onclick="formhash(this.form, this.form.password);" /> 
                                </form>
                            </div>
                        </li>
                        <p style="font-size:1.48em">|</p>
                        <li class="nav-item">
							<a class="nav-link dropdown" href="register.php" id="navbarWelcome" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Register
                            </a>
                            <?php
                                if (!empty($error_msg)) {
                                    echo "<script type='text/javascript'>alert('$error_msg;');document.location='index.php'</script>";
                                }
                            ?>
                            <div class="dropdown-menu" aria-labelledby="navbarWelcome">
                                 <form class="container" style="margin:3px; width: 100%" method="post" name="registration_form" action="<?php echo esc_url($_SERVER['PHP_SELF']); ?>">
									<div class="form-group">
										<input type="text" class="form-control" style="width:100%" name='username' id='username'  placeholder="Username">
									</div>
									<div class="form-group">
										<input type="text" class="form-control" style="width:100%" name="email" id="email" placeholder="Email">
									</div>
									<div class="form-group">
										<input type="password" class="form-control" style="width:100%"  name="password" id="password" placeholder="Password">
									</div>
                                    <div class="form-group">
										<input type="password" class="form-control" style="width:100%"  name="confirmpwd" 
                                     id="confirmpwd" placeholder="Confirm Password">
									</div>
                                    <div class="form-group">
										<input type="text" class="form-control" style="width:100%" name="nama" id='nama' placeholder="Nama Perusahaan">
									</div>
                                    <div class="form-group">
										<input type="text" class="form-control" style="width:100%" name="telpon" id="telpon" placeholder="No. Telephone">
									</div>
                                    <input type="navbar" class="btn btn-primary"  value="Register"   onclick="return regformhash(this.form,
                                   this.form.username,
                                   this.form.email,
                                   this.form.password,
                                   this.form.confirmpwd,
                                   this.form.nama,
                                   this.form.telpon);" /> 
                                    <!-- <button type="navbar" class="btn btn-primary" name="register" href="register.html">Register</button> -->
                                </form>
                            </div>
                        </li>
						<li class="nav-item" style="text-align:center">
                            <a href="#" class="nav-link js-scroll-trigger">
                                Pelatihan
                            </a>
                        </li>
                        <li class="nav-item" style="text-align:center">
                            <a href="#" class="nav-link js-scroll-trigger">
                                Seminar Nasional
                            </a>
                        </li>
                        <li class="nav-item" style="text-align:center">
                            <a href="#" class="nav-link js-scroll-trigger">
                                Seminar Internasional
                            </a>
                        </li>
                </div> <!-- / .navbar-collapse -->
                </div> <!-- / .navbar-collapse -->
        </nav> <!-- / .container -->
    </div>
</div>

    <!-- Brosur
    ================================================== -->
    <section class="section" id="process">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-4 col-sm-6 col-md-6">
                    <div class="process-block">
                        <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
                            <img src="assets/img/paket_a.jpg" alt="" class="img-responsive">
                            </button>
                     
                        <!-- Modal -->
                        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog" role="document">
                            <div class="modal-content" style="width: 100%">
                              <div class="modal-body">
                                <div class="grid-container">    
                                    <div class="grid-item">
                                        <img src="assets/img/paket_a.jpg" alt="" class="img-responsive">
                                    </div>
                                    <div class="grid-item">
                                    <h5 style="text-align: left;">Cara Membuat Pop UP Gambar dengan Bootstrap</h5>
                                    </div>
                                </div>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>   
                              </div>
                            </div>
                          </div>
                        </div>
                        <p></p>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 col-md-6">
                    <div class="process-block">
                        <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
                            <img src="assets/img/paket_a.jpg" alt="" class="img-responsive">
                            </button>
                     
                        <!-- Modal -->
                        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog" role="document">
                            <div class="modal-content" style="width: 100%">
                              <div class="modal-body">
                                <div class="grid-container">    
                                    <div class="grid-item">
                                        <img src="assets/img/paket_a.jpg" alt="" class="img-responsive">
                                    </div>
                                    <div class="grid-item">
                                    <h5 style="text-align: left;">Cara Membuat Pop UP Gambar dengan Bootstrap</h5>
                                    </div>
                                </div>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>   
                              </div>
                            </div>
                          </div>
                        </div>
                        <p></p>
                    </div>
                </div>
				<div class="col-lg-4 col-sm-6 col-md-6">
                    <div class="process-block">
                        <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
                            <img src="assets/img/paket_a.jpg" alt="" class="img-responsive">
                            </button>
                     
                        <!-- Modal -->
                        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                          <div class="modal-dialog" role="document">
                            <div class="modal-content" style="width: 100%">
                              <div class="modal-body">
                                <div class="grid-container">    
                                    <div class="grid-item">
                                        <img src="assets/img/paket_a.jpg" alt="" class="img-responsive">
                                    </div>
                                    <div class="grid-item">
                                    <h5 style="text-align: left;">Cara Membuat Pop UP Gambar dengan Bootstrap</h5>
                                    </div>
                                </div>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>   
                              </div>
                            </div>
                          </div>
                        </div>
                        <p></p>
                        <p></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
	
	<section class="section" id="services-2">
        <div class="container">
            <div class="row justify-content-left">
                <div class="col-md-8 col-lg-6 text-left">
                    <div class="section-heading">
                        <h2 class="section-title mb-2 text-white">
                            INFORMASI WEB
                        </h2>
                    </div>
					<h4 style="color: white">makasih pak gede, love you so much
					.</h4>
                </div>
            </div> <!-- / .row -->
        </div>
    </section>

    <!-- FOOTER
    ================================================== -->
    <footer class="section " id="footer">
        <div class="overlay footer-overlay"></div>
        <!--Content -->
        <div class="container">
            <div class="row justify-content-start">
                <div class="col-lg-4 col-sm-12">
                    <div class="footer-widget">
                        <!-- Brand -->
                       
                    </div>
                </div>

                <div class="col-lg-3 ml-lg-auto col-sm-12">
                    <div class="footer-widget">
                       
                    </div>
                </div>
				
                <div class="col-lg-2 col-sm-6">
                    <div class="footer-widget">
                     
                    </div>
                </div>

                <div class="col-lg-2 col-sm-6">
                    <div class="footer-widget">
                </div>
                </div>
            </div> <!-- / .row -->

            <div class="row text-right pt-5">
                <div class="col-lg-12">
                    <!-- Copyright -->
                    <p class="footer-copy ">
                        &copy; Copyright <span class="current-year"></span> All rights reserved.
                    </p>
                </div>
            </div> <!-- / .row -->
        </div> <!-- / .container -->
    </footer>


    <!--  Page Scroll to Top  -->

    <a class="scroll-to-top js-scroll-trigger" href=".top-header">
        <i class="fa fa-angle-up"></i>
    </a>

    <!-- JAVASCRIPT
    ================================================== -->
    <!-- Global JS -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>

    <!-- Plugins JS -->
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Slick JS -->
    <script src="assets/js/jquery.easing.1.3.js"></script>
    <script src="assets/js/slick.min.js"></script>
    <!-- Theme JS -->
    <script src="assets/js/theme.js"></script>

</body>

</html>