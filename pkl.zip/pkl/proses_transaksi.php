<?php
include 'koneksi.php';

session_start();
        /* Registration process, inserts user info into the database
           and sends account confirmation email message
         */

        // Set session variables to be used on profile.php page
    
    $id = $_GET['ID'];
		$sql = 'SELECT * FROM klien WHERE id=:id';
		$statement = $connection->prepare($sql);
		$statement->execute([':id' => $id]);
		$person = $statement->fetch(PDO::FETCH_OBJ);
    
    $_SESSION['NAMA_SEMINAR'] = $_POST['NAMA_SEMINAR'];
		$_SESSION['JENIS'] = $_POST['JENIS'];
		$_SESSION['BATAS'] = $_POST['BATAS'];
		$_SESSION['LOKASI'] = $_POST['LOKASI'];
		$_SESSION['FILES'] = $_POST['FILES'];
		
$nama_seminar = $connect->escape_string($_POST['NAMA_SEMINAR']);
$jenis = $connect->escape_string($_POST['JENIS']);
$batas = $connect->escape_string($_POST['BATAS']);
$lokasi = $connect->escape_string($_POST['LOKASI']);
$files = $connect->escape_string($_POST['FILES']);

$sql = "INSERT INTO PELANGGAN (NAMA_SEMINAR,JENIS,BATAS,LOKASI,FILES) " . "VALUES ('$nama_seminar','$jenis','$batas','$lokasi','$files')";
if($connect->query($sql)){
	echo "<script type='text/javascript'>alert('Pemesanan Berhasil, Kami Akan Menghubungi Anda Ketika Pesanan Diterima');document.location='index.html'</script>";
}
else {
       echo "<script type='text/javascript'>alert('Ada Data Yang Belum Terisi');document.location='transaksi.php'</script>";
     }
?>