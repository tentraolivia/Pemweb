<?php
//koneksi
$connect = mysqli_connect('localhost','root','','pkl') or die (mysqli_connect_error());
date_default_timezone_set("Asia/Jakarta");

?>