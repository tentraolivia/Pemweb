<?php 
	
	include 'koneksi.php';  
    session_start();
    $dbh = new PDO("mysql:host=localhost;dbname=pkl", "root", "");
    if(isset($_POST['btn'])){
    $nama_seminar = $connect->escape_string($_POST['NAMA_SEMINAR']);
	$jenis = $connect->escape_string($_POST['JENIS']);
	$batas = $connect->escape_string($_POST['BATAS']);
	$lokasi = $connect->escape_string($_POST['LOKASI']);
      $name = $_FILES['myfile']['name'];
      $type = $_FILES['myfile']['type'];
      $data = file_get_contents($_FILES['myfile']['tmp_name']);
      $stmt = $dbh->prepare("insert into seminar values('',?,?,?,?,?,?,?)");
      $stmt->bindParam(1,$nama_seminar);
      $stmt->bindParam(2,$jenis);
      $stmt->bindParam(3,$batas);
      $stmt->bindParam(4,$lokasi);
      $stmt->bindParam(5,$name);
      $stmt->bindParam(6,$type);
      $stmt->bindParam(7,$data);
      $stmt->execute();
      $insert = $stmt;
    }
		if($insert){
			echo "<script type='text/javascript'>alert('Seminar Berhasil Diupload');document.location='user.php'</script>";
		}
		else{
			echo "<script type='text/javascript'>alert('Seminar Gagal Diupload');document.location='upload.php'</script>";
		}
?>